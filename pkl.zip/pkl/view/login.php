<!DOCTYPE html>
<html lang="en">
<head>
<title>Prakerin </title>
	<!-- Meta tags -->
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Jolly Login Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Meta tags -->


<!-- font-awesome icons -->
   <link rel="stylesheet" href="./lib/css/font-awesome.min.css" />

<!-- //font-awesome icons -->
<!--stylesheets-->
<link href="./lib/css/style.css" rel='stylesheet' type='text/css' media="all">
<!--//style sheet end here-->

<link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">

<script src="./lib/ie-emulation-modes-warning.js"></script>

</head>
<body>

<h1>Login PKL</h1>

<div class="main-w3">
   <form method="post" action="model/proses.php">
        <h2><span class="fa fa-user t-w3" aria-hidden="true"></span></h2>
		
		 <?php 
            if (isset($_GET['log'])) {
                if ($_GET['log']==2) {
                    echo "<div class='alert alert-danger'><strong>Periksa kembali email & katasandi Anda!</strong></div>";
                }
            }
         ?>
		
     <div class="login-w3ls">
         <div class="icons">
             
		    <input type="email" name="email" id="inputEmail" placeholder="Email" required="">
			<span class="fa fa-user" aria-hidden="true"></span>
          <div class="clear"></div> 
		</div> 		   
		 <div class="icons">
				<input for="inputPassword" type="password" name="pwd" id="inputPassword" placeholder="Password" required="">
				<span class="fa fa-key" aria-hidden="true"></span>
		         <div class="clear"></div>
		</div>
	     <div class="btnn">
	          <button type="submit" name="login" value="sign-in">Login</button><br>
        </div>	
     </div>
   </form>

 </div> 
 
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="./lib/ie10-viewport-bug-workaround.js"></script>

    <div class="copy">
    <p>&copy;2017 @BUdi</p>.
</div>
</body>
</html>